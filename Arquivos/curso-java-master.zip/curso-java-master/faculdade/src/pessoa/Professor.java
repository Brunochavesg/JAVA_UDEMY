package pessoa;

public class Professor {

}
