package fundamentos;

/**
 * 
 * @author leonardomleitao
 * @since JDK1.0
 */
public class PrimeiroPrograma {

	/**
	 * ...
	 * @param args
	 */
	public static void main(String[] args) {
		
		// Sentença de código termina com ;
		// Mais uma linha...
		// Fim
		System.out.println("Primeiro programa Parte #01!");
		
		/*
		 * Linha 1
		 * Linha 2
		 * Linha 3
		 */
		System.out.println("Primeiro programa Parte #02!");
	}
}
