open module app.logging {
	exports br.com.cod3r.app.logging;
}