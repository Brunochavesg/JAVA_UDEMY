package br.com.cod3r.cm.excecao;

public class SairException extends RuntimeException {

	private static final long serialVersionUID = 1;

}
