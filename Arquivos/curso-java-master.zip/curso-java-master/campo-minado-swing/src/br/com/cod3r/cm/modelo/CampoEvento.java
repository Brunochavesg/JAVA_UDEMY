package br.com.cod3r.cm.modelo;

public enum CampoEvento {

	ABRIR, MARCAR, DESMARCAR, EXPLODIR, REINICIAR
}
